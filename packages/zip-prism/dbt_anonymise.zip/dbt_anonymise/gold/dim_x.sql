SELECT
    a.sub,
    b.col_5,

    concat(
        coalesce(b.col_6, a.col_10),
        ' ',
        coalesce(b.col_8, a.col_9)
    ) AS col_15,

    b.col_10,
    b.col_11,

    d.col_14 AS col_16,
    CASE
        WHEN c.col_13 = 'M' THEN 'Membre'
        WHEN c.col_13 = 'C' THEN 'Chef'
    END AS col_17,

    a.sub IS NOT NULL AS col_18,
    b.col_5 IS NOT NULL AS col_19

FROM {{ ref('table_d') }} AS a

FULL OUTER JOIN {{ ref('table_e') }} AS b
    ON
        a.col_9 = b.col_8
        AND a.col_10 = b.col_6

LEFT JOIN {{ ref('table_f') }} AS c
    ON b.col_5 = c.col_5

LEFT JOIN {{ ref('table_g') }} AS d
    ON
        c.col_12 == d.col_12
        AND d.col_16 IS NULL
