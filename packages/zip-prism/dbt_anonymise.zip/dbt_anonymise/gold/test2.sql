WITH
cte_a AS (
    SELECT
        col_2,
        sum(col_3) AS col_3,
        col_5
    FROM {{ ref('table_h') }}
    WHERE col_5 = 1
    GROUP BY col_2, col_5
),

cte_b AS (
    SELECT
        col_2,
        sum(col_3) AS col_3,
        col_5
    FROM {{ ref('table_h') }}
    WHERE col_5 = 3
    GROUP BY col_2, col_5
),

cte_c AS (
    SELECT
        col_2,
        sum(col_3) AS col_3,
        col_5
    FROM {{ ref('table_h') }}
    WHERE col_5 = 4
    GROUP BY col_2, col_5
),

cte_d AS (
    SELECT
        col_2,
        sum(col_3) AS col_3,
        col_5
    FROM {{ ref('table_h') }}
    WHERE col_5 = 5
    GROUP BY col_2, col_5
),

cte_e AS (
    SELECT
        col_2,
        sum(col_3) AS col_3,
        col_5
    FROM {{ ref('table_h') }}
    WHERE col_5 = 6
    GROUP BY col_2, col_5
),

cte_f AS (
    SELECT
        col_2,
        col_3,
        count(col_9) AS col_20
    FROM {{ ref('table_i') }}
    WHERE
        col_4 = 2
        AND col_9 IS NOT NULL
    GROUP BY col_2, col_3
),

cte_g AS (
    SELECT *
    FROM {{ ref('table_j') }}
    LIMIT 1
)


SELECT
    a.col_1 AS col_100,
    a.col_10 AS col_101,
    a.col_12 AS col_102,
    a.col_2 AS col_103,
    a.col_18 AS col_104,
    a.col_17 AS col_105,
    a.col_4 AS col_106,
    CASE
        WHEN a.col_4 = 0 THEN 'cat_1'
        WHEN a.col_4 = 1 THEN 'cat_2'
        WHEN a.col_4 = 2 THEN 'cat_3'
        WHEN a.col_4 = 3 THEN 'cat_4'
        WHEN a.col_4 = 4 THEN 'cat_5'
        WHEN a.col_4 = 5 THEN 'cat_6'
        WHEN a.col_4 = 6 THEN 'cat_7'
        WHEN a.col_4 = 7 THEN 'cat_8'
    END::VARCHAR(30) AS col_107,

    a.col_19 AS col_108,
    {{ date_parts('a.col_19') }},
    {{ year_flags('a.col_19') }},

    a.col_33 AS col_113,

    k.col_4 AS col_114,

    coalesce(m.col_4, 'N/A') AS col_115,

    a.col_55 AS col_116,
    coalesce(u1.col_2, 'N/A') AS col_117,
    coalesce(u1.col_3, 'N/A') AS col_118,

    a.col_3_list AS col_119,
    coalesce(u2.col_2, 'N/A') AS col_120,
    coalesce(u2.col_3, 'N/A') AS col_121,

    a.col_51 AS col_122,
    coalesce(u3.col_2, 'N/A') AS col_123,
    coalesce(u3.col_3, 'N/A') AS col_124,

    u2.col_6 AS col_125,
    coalesce(u4.col_2, 'N/A') AS col_126,
    coalesce(u4.col_3, 'N/A') AS col_127,

    coalesce(o.col_2, 'N/A')::VARCHAR(30) AS col_128,

    l.col_1 AS col_129,
    l.col_6 AS col_130,

    CASE
        WHEN l.col_10 = 1 THEN concat(chr(8203), 'cat_1')
        WHEN l.col_10 = 2 THEN 'cat_2'
        WHEN l.col_10 = 9 THEN 'cat_3'
        ELSE 'N/A'
    END::VARCHAR(20) AS col_131,

    coalesce(n.col_11, 'N/A')::VARCHAR(30) AS col_132,

    CASE
        WHEN cte_f.col_20 IS NOT NULL THEN 'cat_1'
        WHEN a.col_13 = 2 THEN 'cat_2'
        ELSE 'cat_3'
    END::VARCHAR(30) AS col_133,

    a.col_19 IS NOT NULL AS col_134,
    CASE
        WHEN a.col_19 IS NULL
            THEN 'cat_1'
        WHEN a.col_2 IS NULL
            THEN 'cat_2'
        WHEN a.col_19 = a.col_2
            THEN 'cat_3'
        WHEN a.col_19 < a.col_2
            THEN 'cat_4'
        WHEN a.col_19 > a.col_2
            THEN 'cat_5'
    END AS col_135,

    CASE
        WHEN a.col_19 < a.col_2
            THEN datediff('day', a.col_19, a.col_2)
    END AS col_136,
    CASE
        WHEN a.col_19 > a.col_2
            THEN datediff('day', a.col_2, a.col_19)
    END AS col_137,

    sum(coalesce(cte_a.col_3, 0)) AS col_138,
    sum(coalesce(cte_b.col_3, 0)) AS col_139,
    sum(coalesce(cte_c.col_3, 0)) AS col_140,
    sum(coalesce(cte_d.col_3, 0)) AS col_141,
    sum(coalesce(cte_e.col_3, 0)) AS col_142,
    nullif(
        sum(
            coalesce(cte_a.col_3, 0)
            + coalesce(cte_b.col_3, 0)
            + coalesce(cte_e.col_3, 0)
        ),
        0
    ) AS col_143,
    cte_g.col_2 AS col_144,
    cte_g.col_3 AS col_145

FROM {{ ref('table_a') }} AS a

LEFT JOIN {{ ref('table_k') }} AS k
    ON a.col_8 = k.col_1

LEFT JOIN {{ ref('table_l') }} AS l
    ON a.col_5 = l.col_1

LEFT JOIN {{ ref('table_m') }} AS m
    ON
        l.col_5 = m.col_2
        AND m.col_1 = 8

LEFT JOIN {{ ref('table_n') }} AS n
    ON a.col_5 = n.col_1 AND a.col_6 = n.col_2

LEFT JOIN {{ ref('table_d') }} AS u1
    ON a.col_55 = u1.sub

LEFT JOIN {{ ref('table_d') }} AS u2
    ON a.col_3_list = u2.sub

LEFT JOIN {{ ref('table_d') }} AS u3
    ON a.col_51 = u3.sub

LEFT JOIN {{ ref('table_d') }} AS u4
    ON u2.col_6 = u4.sub

LEFT JOIN {{ ref('table_o') }} AS o
    ON l.col_3 = o.col_1

LEFT JOIN {{ ref('table_p') }} AS p
    ON a.col_1 = p.col_2

LEFT JOIN cte_a
    ON p.col_1 = cte_a.col_2

LEFT JOIN cte_b
    ON p.col_1 = cte_b.col_2

LEFT JOIN cte_c
    ON p.col_1 = cte_c.col_2

LEFT JOIN cte_d
    ON p.col_1 = cte_d.col_2

LEFT JOIN cte_e
    ON p.col_1 = cte_e.col_2

LEFT JOIN cte_f
    ON
        a.col_5 = cte_f.col_2
        AND a.col_6 = cte_f.col_3

CROSS JOIN cte_g

GROUP BY
    a.col_1, a.col_10, a.col_12, a.col_2, a.col_18, a.col_17,
    a.col_4, a.col_19, a.col_33, a.col_13,
    col_107, k.col_4,
    a.col_55, u1.col_2, u1.col_3,
    a.col_3_list, u2.col_2, u2.col_3,
    a.col_51, u3.col_2, u3.col_3,
    u2.col_6, u4.col_2, u4.col_3,
    o.col_2,
    l.col_1, l.col_6, l.col_10, m.col_4, col_131,
    n.col_11, cte_f.col_20,
    cte_g.col_2, cte_g.col_3
