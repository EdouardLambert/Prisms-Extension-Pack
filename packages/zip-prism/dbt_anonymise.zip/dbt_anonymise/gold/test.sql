WITH
cte_a AS (
    SELECT
        col_1,
        col_2,
        col_3_list AS col_3_sub

    FROM {{ ref('table_a') }}

    WHERE
        col_4 NOT IN (5, 6)
        AND col_2 >= current_date()
        AND trim(col_3_list) <> ''
),

cte_b AS (
    SELECT
        tb.col_5 AS col_6,
        tb.col_7,
        tb.col_8,

        tb_type.col_9 AS col_10

    FROM {{ ref('table_b') }} AS tb

    LEFT JOIN {{ ref('table_c') }} AS tb_type
        ON tb.col_11 = tb_type.col_12

    WHERE tb.col_8 >= current_date()
)


SELECT
    a.col_1 AS col_13,
    a.col_2 AS col_14,

    coalesce(j.col_15, 'N/A') AS col_15,
    coalesce(j.col_16, 'N/A') AS col_16,

    b.col_7 AS col_17,
    b.col_8 AS col_18,
    b.col_10,

    CASE
        WHEN b.col_7 IS NULL OR b.col_8 IS NULL
            THEN NULL
        WHEN a.col_2 BETWEEN b.col_7 AND b.col_8
            THEN 'cat_1'
        WHEN
            least(
                abs(datediff('day', a.col_2, b.col_7)),
                abs(datediff('day', a.col_2, b.col_8))
            ) <= 3
            THEN 'cat_2'
        WHEN
            least(
                abs(datediff('day', a.col_2, b.col_7)),
                abs(datediff('day', a.col_2, b.col_8))
            ) <= 14
            THEN 'cat_3'
        ELSE 'cat_4'
    END AS col_19

FROM cte_a AS a

LEFT JOIN {{ ref('dim_x') }} AS j
    ON a.col_3_sub = j.sub

LEFT JOIN cte_b AS b
    ON j.col_5 = b.col_6

QUALIFY row_number() OVER (
    PARTITION BY a.col_1
    ORDER BY
        CASE
            WHEN b.col_7 IS NULL THEN 1
            ELSE 0
        END,
        abs(
            datediff(
                'day',
                a.col_2,
                b.col_7
            )
        )
) = 1
