# Arborescence du sous-ensemble dbt anonymisé

Vue de l'arborescence et du grappe de dépendances **`ref()`** des fichiers
anonymisés uniquement. Les noms réels (`acte`, `utilisateur`, `activite_acte`,
`acte_risque_absence`, `dim_collaborateur`, …) sont remplacés par le
vocabulaire factice `table_*` / `test` / `test2` / `dim_x`.

Légende sources : `src_a` = authentique, `src_b` = humain/jurisweb.

---

## 1. Arborescence des fichiers

```
dbt/models/
├── fake_schema.yml                 # schéma factice (16 silver + 3 gold)
├── arborescence.md                 # ce fichier
│
├── silver/                         # 16 modèles silver anonymisés
│   ├── table_a.sql                 #   src_a  · incremental · pk col_1      (58 cols)
│   ├── table_b.sql                 #   src_b  · table       · pk col_5 · contract ( 9 cols)
│   ├── table_c.sql                 #   src_b  · table       · pk col_5 · contract ( 6 cols)
│   ├── table_d.sql                 #   src_a  · incremental · pk sub          ( 9 cols)
│   ├── table_e.sql                 #   src_b  · table       · pk col_5 · contract ( 6 cols)
│   ├── table_f.sql                 #   src_b  · table       · pk col_12 · contract( 4 cols)
│   ├── table_g.sql                 #   src_b  · incremental · pk col_12 · contract( 6 cols)
│   ├── table_h.sql                 #   src_b  · incremental · pk col_1      (12 cols)
│   ├── table_i.sql                 #   src_a  · incremental · pk col_1      (11 cols)
│   ├── table_j.sql                 #   src_a  · incremental · pk col_1       ( 4 cols)
│   ├── table_k.sql                 #   src_a  · incremental · pk col_1      (34 cols)
│   ├── table_l.sql                 #   src_a  · incremental · pk col_1      (31 cols)
│   ├── table_m.sql                 #   src_a  · incremental · pk col_1      (10 cols)
│   ├── table_n.sql                 #   src_a  · incremental · pk col_1      (17 cols)
│   ├── table_o.sql                 #   src_a  · incremental · pk col_1       ( 2 cols)
│   └── table_p.sql                 #   src_b  · incremental · pk col_1      (12 cols)
│
└── gold/                           # 3 modèles gold anonymisés
    ├── test.sql                    #   = acte_risque_absence (8 colonnes, QUALIFY row_number)
    ├── test2.sql                   #   = activite_acte       (52 colonnes, 7 CTE, GROUP BY)
    └── dimensions/
        └── dim_x.sql               #   = dim_collaborateur   (9 colonnes, FULL OUTER JOIN)
```

---

## 2. Graphe de dépendances `ref()`

Flux dbt de haut en bas : **gold → silver → bronze**. Chaque flèche
`A ← B` signifie « `A` référence `B` dans son `ref()` ».

```
                         ┌──────────────────────────────────────────────┐
                         │                       GOLD                     │
                         └──────────────────────────────────────────────┘
   ┌───────────┐   ┌───────────┐   ┌──────────────────────────────────────────┐
   │   test    │   │   test2   │   │                 dim_x                    │
   └─────┬─────┘   └─────┬─────┘   └──────────────────────────────────────────┘
         │                │                     │
         │                │        ┌────────────┼────────────┬────────────┐
         │                │        │            │            │            │
         │                │       table_d     table_e      table_f      table_g
         │                │        │            │            │            │
         ├────────┬───────┼────────┤            │            │            │
         │        │       │        │            │            │            │
        table_a table_b table_c   │            │            │            │
         │        │       │        │            │            │            │
         │        │       │       table_k     table_l     table_m        │
         │        │       │        │            │            │            │
         │        │       │      table_n     table_o     table_p         │
         │        │       │        │            │            │            │
         │        │       │      table_h     table_i     table_j         │
         │        │       │        │            │            │            │
        ┌─────────┴────────┴────────┴────────────┴────────────┴────────────┘
        │                     SILVER  (16 modèles)                    │
        └──────────────────────────────────────────────────────────────────┘
                                   │
                         ┌─────────┴─────────┐
                         │       BRONZE       │
                         ├────────────────────┤
   src_a (authentique)   │ t_a t_d t_i t_j   │
   src_b (humain/jw)     │ t_k t_l t_m t_n   │
                         │ t_o t_b t_c t_e   │
                         │ t_f t_g t_h t_p   │
                         └────────────────────┘
```

### Détail par modèle gold (ses `ref()` directs)

| Modèle gold | `ref()` directs |
|---|---|
| `dim_x` | `table_d`, `table_e`, `table_f`, `table_g` |
| `test`  | `table_a`, `table_b`, `table_c`, `dim_x` |
| `test2` | `table_a`, `table_d`, `table_k`, `table_l`, `table_m`, `table_n`, `table_o`, `table_p` **+ CTE** sur `table_h`, `table_i`, `table_j` |

> `test2` consomme `table_h` (5 CTE `cte_a`..`cte_e`), `table_i` (CTE `cte_f`)
> et `table_j` (CTE `cte_g`) via des CTE, en plus de ses 8 `ref()` directs de tables.

---

## 3. Récapitulatif silver → source

| Silver | Source | Materialisation | pk (unique_key) | contract |
|---|---|---|---|---|
| `table_a` | src_a | incremental | `col_1` | — |
| `table_b` | src_b | table | `col_5` | ✓ |
| `table_c` | src_b | table | `col_5` | ✓ |
| `table_d` | src_a | incremental | `sub` | — |
| `table_e` | src_b | table | `col_5` | ✓ |
| `table_f` | src_b | table | `col_12` | ✓ |
| `table_g` | src_b | incremental | `col_12` | ✓ |
| `table_h` | src_b | incremental | `col_1` | — |
| `table_i` | src_a | incremental | `col_1` | — |
| `table_j` | src_a | incremental | `col_1` | — |
| `table_k` | src_a | incremental | `col_1` | — |
| `table_l` | src_a | incremental | `col_1` | — |
| `table_m` | src_a | incremental | `col_1` | — |
| `table_n` | src_a | incremental | `col_1` | — |
| `table_o` | src_a | incremental | `col_1` | — |
| `table_p` | src_b | incremental | `col_1` | — |

---

## Notes

- `fake_schema.yml` (à `dbt/models/fake_schema.yml`) contient la définition
  colonne par colonne de ces 19 modèles. Les `data_type` des modèles
  non-contractuels sont des **placeholders** reflétant la structure d'origine ;
  les modèles contractuels exigent la définition complète (présente ici).
- `dbt_project.yml` et les `schema.yml` réels ne sont **pas** modifiés :
  lancer `dbt compile` sur les modèles anonymisés échouerait (noms inconnus,
  types placeholders). Ce sous-ensemble est une maquette de référence, pas un
  projet dbt exécutable.
