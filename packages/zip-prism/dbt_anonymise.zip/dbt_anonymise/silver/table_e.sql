{{ config(
    materialized='table',
    unique_key='col_5',
    contract={'enforced': true},
    meta={'source_system': 'src_b'}
) }}

{% set bronze_path = env_var("CLIENT_PATH") ~ "/bronze/src_b/" ~ model.name ~ ".parquet" %}

SELECT
    col_5::INTEGER AS col_5,
    col_1::INTEGER AS col_1,
    upper(col_8)::VARCHAR AS col_8,
    col_6::VARCHAR AS col_6,
    {{ clean_date('col_10') }}::DATE AS col_10,
    {{ clean_date('col_11') }}::DATE AS col_11

FROM read_parquet('{{ bronze_path }}')
