{{ config(
    materialized='incremental',
    unique_key='col_1'
) }}

{% set table_source = "t_n" %}
{% set bronze_path = env_var("CLIENT_PATH") ~ "/bronze/src_a/" ~ table_source ~ ".parquet" %}

SELECT
    col_1,
    col_2,
    col_3,
    {{ clean_text('col_4') }} AS col_4,
    {{ clean_text('col_5') }} AS col_5,
    {{ clean_text('col_6') }} AS col_6,
    {{ clean_text('col_7') }} AS col_7,
    {{ clean_text('col_8') }} AS col_8,
    {{ clean_text('col_9') }} AS col_9,
    {{ clean_text('col_10') }} AS col_10,
    {{ clean_text('col_11') }} AS col_11,
    {{ clean_text('col_12') }} AS col_12,
    {{ safe_cast('col_13', 'DATE') }} AS col_13,
    {{ clean_bool('col_14') }} AS col_14,
    col_15,
    col_16,
    col_17

FROM read_parquet('{{ bronze_path }}')

{% if is_incremental() %}
    WHERE col_16 >= ({{ max_date_update('col_16') }} FROM {{ this }})
{% endif %}
