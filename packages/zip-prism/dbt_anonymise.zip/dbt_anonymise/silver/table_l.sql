{{ config(
    materialized='incremental',
    unique_key='col_1'
) }}

{% set table_source = "t_l" %}
{% set bronze_path = env_var("CLIENT_PATH") ~ "/bronze/src_a/" ~ table_source ~ ".parquet" %}

SELECT
    col_1,
    col_2,
    {{ clean_text('col_3') }} AS col_3,
    col_4,
    col_5,
    {{ clean_date('col_6') }} AS col_6,
    {{ clean_date('col_7') }} AS col_7,
    {{ clean_date('col_8') }} AS col_8,
    {{ clean_date('col_9') }} AS col_9,
    col_10,
    {{ clean_date('col_11') }} AS col_11,
    {{ clean_date('col_12') }} AS col_12,
    {{ clean_text('col_13') }} AS col_13,
    {{ clean_date('col_14') }} AS col_14,
    {{ clean_text('col_15') }} AS col_15,
    {{ clean_bool('col_16') }} AS col_16,
    col_17,
    {{ clean_text('col_18') }} AS col_18,
    {{ clean_bool('col_19') }} AS col_19,
    {{ clean_date('col_20') }} AS col_20,
    {{ clean_date('col_21') }} AS col_21,
    {{ clean_text('col_22') }} AS col_22,
    {{ clean_text('col_23') }} AS col_23,
    {{ clean_text('col_24') }} AS col_24,
    {{ clean_text('col_25') }} AS col_25,
    {{ clean_bool('col_26') }} AS col_26,
    {{ clean_text('col_27') }} AS col_27,
    {{ clean_text('col_28') }} AS col_28,
    {{ clean_text('col_29') }} AS col_29,
    col_30,
    {{ clean_date('col_31') }} AS col_31

FROM read_parquet('{{ bronze_path }}')

{% if is_incremental() %}
    WHERE col_31 >= ({{ max_date_update('col_31') }} FROM {{ this }})
{% endif %}
