{{ config(
    materialized='incremental',
    unique_key='col_1'
) }}

{% set table_source = "t_i" %}
{% set bronze_path = env_var("CLIENT_PATH") ~ "/bronze/src_a/" ~ table_source ~ ".parquet" %}
SELECT
    col_1,
    col_2,
    col_3,
    col_4,
    col_5,
    col_6,
    col_7,
    col_8,
    col_9,
    {{ clean_int('col_10') }} AS col_10,
    col_11

FROM read_parquet('{{ bronze_path }}')

{% if is_incremental() %}
    WHERE col_1 NOT IN (SELECT target.col_1 FROM {{ this }} AS target)
{% endif %}
