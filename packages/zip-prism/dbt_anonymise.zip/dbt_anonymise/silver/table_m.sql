{{ config(
    materialized='incremental',
    unique_key='col_1'
) }}

{% set table_source = "t_m" %}
{% set bronze_path = env_var("CLIENT_PATH") ~ "/bronze/src_a/" ~ table_source ~ ".parquet" %}

SELECT
    col_1,
    col_2,
    {{ clean_text('col_3') }} AS col_3,
    {{ clean_text('col_4') }} AS col_4,
    col_5,
    {{ clean_text('col_6') }} AS col_6,
    col_7,
    {{ clean_text('col_8') }} AS col_8,
    col_9,
    col_10

FROM read_parquet('{{ bronze_path }}')

{% if is_incremental() %}
    WHERE col_10 >= ({{ max_date_update('col_10') }} FROM {{ this }})
{% endif %}
