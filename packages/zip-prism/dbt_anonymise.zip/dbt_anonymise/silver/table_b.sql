{{ config(
    materialized='table',
    unique_key='col_1',
    contract={'enforced': true},
    meta={'source_system': 'src_b'}
) }}

{% set bronze_path = env_var("CLIENT_PATH") ~ "/bronze/src_b/" ~ model.name ~ ".parquet" %}

SELECT
    col_5::INTEGER AS col_5,
    col_6::INTEGER AS col_6,
    col_10::SMALLINT AS col_10,
    {{ clean_date('col_7') }}::TIMESTAMP AS col_7,
    {{ clean_date('col_8') }}::TIMESTAMP AS col_8,
    col_13::DOUBLE AS col_13,
    col_11::VARCHAR AS col_11,
    {{ clean_date('col_14') }}::TIMESTAMP AS col_14,
    col_15::BOOL AS col_15

FROM read_parquet('{{ bronze_path }}')
