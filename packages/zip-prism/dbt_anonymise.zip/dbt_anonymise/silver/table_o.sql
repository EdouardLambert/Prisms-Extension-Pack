{{ config(
    materialized='incremental',
    unique_key='col_1'
) }}

{% set table_source = "t_o" %}
{% set bronze_path = env_var("CLIENT_PATH") ~ "/bronze/src_a/" ~ table_source ~ ".parquet" %}

SELECT
    col_1,
    col_2

FROM read_parquet('{{ bronze_path }}')

{% if is_incremental() %}
    WHERE col_1 NOT IN (SELECT target.col_1 FROM {{ this }} AS target)
{% endif %}
