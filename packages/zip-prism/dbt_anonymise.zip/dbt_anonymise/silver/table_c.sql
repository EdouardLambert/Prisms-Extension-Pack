{{ config(
    materialized='table',
    unique_key='col_12',
    contract={'enforced': true},
    meta={'source_system': 'src_b'}
) }}

{% set bronze_path = env_var("CLIENT_PATH") ~ "/bronze/src_b/" ~ model.name ~ ".parquet" %}

SELECT
    col_12::VARCHAR AS col_12,
    col_9::VARCHAR AS col_9,
    {{ clean_bool("col_16") }}::BOOL AS col_16,
    col_17::VARCHAR AS col_17

FROM read_parquet('{{ bronze_path }}')
