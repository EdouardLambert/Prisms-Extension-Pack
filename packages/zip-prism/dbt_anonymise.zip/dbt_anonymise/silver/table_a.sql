{{ config(
    materialized='incremental',
    unique_key='col_1'
) }}

{% set table_source = "t_a" %}
{% set bronze_path = env_var("CLIENT_PATH") ~ "/bronze/src_a/" ~ table_source ~ ".parquet" %}

SELECT
    col_1,
    col_5,
    col_6,
    col_7,
    col_8,
    col_9,
    {{ clean_date('col_10') }} AS col_10,
    {{ clean_bool('col_11') }} AS col_11,
    {{ clean_int('col_12') }} AS col_12,
    col_13,
    {{ clean_bool('col_14') }} AS col_14,
    col_15,
    col_16,
    col_17,
    {{ clean_date('col_2') }} AS col_2,
    {{ clean_date('col_18') }} AS col_18,
    col_4,
    {{ clean_date('col_19') }} AS col_19,
    col_20,
    col_21,
    col_22,
    col_23,
    col_24,
    col_25,
    col_26,
    {{ clean_bool('col_27') }} AS col_27,
    {{ clean_text('col_28') }} AS col_28,
    {{ clean_text('col_29') }} AS col_29,
    {{ clean_bool('col_30') }} AS col_30,
    col_31,
    col_32,
    col_33,
    col_34,
    {{ clean_bool('col_35') }} AS col_35,
    col_36,
    {{ clean_bool('col_37') }} AS col_37,
    {{ clean_bool('col_38') }} AS col_38,
    {{ safe_cast('col_39', 'DATE') }} AS col_39,
    {{ clean_text('col_40') }} AS col_40,
    {{ clean_text('col_41') }} AS col_41,
    {{ clean_text('col_42') }} AS col_42,
    col_43,
    col_44,
    {{ clean_text('col_45') }} AS col_45,
    {{ clean_text('col_46') }} AS col_46,
    {{ clean_text('col_47') }} AS col_47,
    {{ clean_bool('col_48') }} AS col_48,
    {{ clean_text('col_49') }} AS col_49,
    {{ safe_cast('col_50', 'DATE') }} AS col_50,
    regexp_extract(
        col_3_list,
        '([a-f0-9]{32})',
        1
    ) AS col_3_list,
    regexp_extract(
        col_51,
        '([a-f0-9]{32})',
        1
    ) AS col_51,
    col_52,
    col_53,
    col_54,
    {{ clean_text('col_55') }} AS col_55,
    {{ clean_text('col_56') }} AS col_56,
    {{ clean_text('col_57') }} AS col_57,
    col_58

FROM read_parquet('{{ bronze_path }}')

{% if is_incremental() %}
    WHERE col_54 >= ({{ max_date_update('col_54') }} FROM {{ this }})
{% endif %}
