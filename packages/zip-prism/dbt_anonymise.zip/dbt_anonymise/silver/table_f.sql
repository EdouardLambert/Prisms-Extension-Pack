{{ config(
    materialized='table',
    unique_key='col_5',
    contract={'enforced': true},
    meta={'source_system': 'src_b'}
) }}

{% set bronze_path = env_var("CLIENT_PATH") ~ "/bronze/src_b/" ~ model.name ~ ".parquet" %}

SELECT
    col_1::BIGINT AS col_1,
    col_12::BIGINT AS col_12,
    col_13::CHAR AS col_13,
    col_2::DATE AS col_2,
    col_3::DATE AS col_3,
    col_5::BIGINT AS col_5

FROM read_parquet('{{ bronze_path }}')
