{{ config(
    materialized='incremental',
    unique_key='col_1'
) }}

{% set table_source = "t_k" %}
{% set bronze_path = env_var("CLIENT_PATH") ~ "/bronze/src_a/" ~ table_source ~ ".parquet" %}
SELECT
    col_1,
    col_2,
    col_3,
    {{ clean_text('col_4') }} AS col_4,
    {{ clean_bool('col_5') }} AS col_5,
    {{ clean_bool('col_6') }} AS col_6,
    col_7,
    col_8,
    col_9,
    {{ clean_bool('col_10') }} AS col_10,
    {{ clean_bool('col_11') }} AS col_11,
    col_12,
    col_13,
    col_14,
    {{ clean_bool('col_15') }} AS col_15,
    {{ clean_bool('col_16') }} AS col_16,
    {{ clean_bool('col_17') }} AS col_17,
    col_18,
    col_19,
    {{ clean_bool('col_20') }} AS col_20,
    {{ clean_bool('col_21') }} AS col_21,
    {{ clean_bool('col_22') }} AS col_22,
    col_23,
    {{ clean_bool('col_24') }} AS col_24,
    {{ clean_bool('col_25') }} AS col_25,
    {{ clean_bool('col_26') }} AS col_26,
    {{ clean_text('col_27') }} AS col_27,
    {{ clean_bool('col_28') }} AS col_28,
    {{ clean_text('col_29') }} AS col_29,
    {{ clean_text('col_30') }} AS col_30,
    col_31,
    col_32,
    col_33,
    col_34

FROM read_parquet('{{ bronze_path }}')

{% if is_incremental() %}
    WHERE col_32 >= ({{ max_date_update('col_32') }} FROM {{ this }})
{% endif %}
