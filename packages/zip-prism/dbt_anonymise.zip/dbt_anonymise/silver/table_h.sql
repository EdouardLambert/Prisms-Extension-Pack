{{ config(
    materialized='incremental',
    unique_key='col_1'
) }}

{% set table_source = "t_h" %}
{% set bronze_path = env_var("CLIENT_PATH") ~ "/bronze/src_b/" ~ table_source ~ ".parquet" %}
SELECT
    col_1,
    col_2,
    col_3,
    col_4,
    col_5,
    col_6,
    col_7,
    col_8,
    col_9,
    col_10,
    col_11,
    col_12

FROM read_parquet('{{ bronze_path }}')
