{{ config(
    materialized='incremental',
    unique_key='sub'
) }}

{% set table_source = "t_d" %}
{% set bronze_path = env_var("CLIENT_PATH") ~ "/bronze/src_a/" ~ table_source ~ ".parquet" %}

SELECT
    sub,
    col_1,
    col_2,
    col_3,
    col_9,
    col_10,
    col_4,
    col_5,
    {{ safe_cast('col_6', 'TEXT') }} AS col_6

FROM read_parquet('{{ bronze_path }}')

WHERE
    col_4 = TRUE
    AND sub != '-1'
    {% if is_incremental() %}
        AND col_5 > ({{ max_date_update('col_5') }} FROM {{ this }})
    {% endif %}
