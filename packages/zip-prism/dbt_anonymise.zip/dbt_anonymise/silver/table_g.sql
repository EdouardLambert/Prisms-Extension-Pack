{{ config(
    materialized='incremental',
    unique_key='col_12',
    on_schema_change='append_new_columns',
    contract={'enforced': true},
    meta={'source_system': 'src_b'}
) }}

{% set bronze_path = env_var("CLIENT_PATH") ~ "/bronze/src_b/" ~ model.name ~ ".parquet" %}

SELECT
    col_12::BIGINT AS col_12,
    col_14::VARCHAR AS col_14,
    col_15::DATE AS col_15,
    col_16::DATE AS col_16,
    col_17::TIMESTAMP AS col_17,
    col_18::TIMESTAMP AS col_18

FROM read_parquet('{{ bronze_path }}')

{% if is_incremental() %}
    WHERE col_18 >= ({{ max_date_update('col_18') }} FROM {{ this }})
{% endif %}
